// Express initialization
var express = require('express');
var routes = require('./routes/handle');
var app = express(express.logger());
app.use(express.bodyParser());
app.use(express.methodOverride());
app.set('title', 'nodeapp');

app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.logger('dev'));

app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.use(express.static(__dirname + '/public'));
app.get('/', routes.index);
app.get('/usersearch', routes.usersearch);


app.post('/usersearch', routes.post_search_results);
app.get('/usersearch/:id', routes.search_results);

app.get('/highscores.json', routes.highscores);

app.get('/data.json', function(request, response) {
	response.set('Content-Type', 'text/json');
	response.send('{"status":"good"}');
});

app.post('/submit.json', routes.post_submit);

app.get('/fool', function(request, response) {
	response.set('Content-Type', 'text/html');
	response.send(500, 'Something broke!');
});

app.listen(process.env.PORT || 3000);