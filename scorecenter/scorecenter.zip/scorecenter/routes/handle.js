// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

//Route for Home page
exports.index = function (request, response) {

	response.set('Content-Type', 'text/JSON');
	
		db.collection('highscores', function(er, collection) {
		  collection.find().toArray(function(err, docs) {
		  		response.send(docs);
          });
        });
}

//Route for Search Page
exports.usersearch = function(req, res){
  res.render('usersearch', { title: 'User Search'})
  var result = req.body.search;
  if(result){
	  res.send({redirect: '/usersearch/'+result});
  }
 
}


//Route for Results page
exports.search_results = function (request, response) {

	response.set('Content-Type', 'text/JSON');
	
		db.collection('highscores', function(er, collection) {
		  collection.find({"username" : request.params.id }).toArray(function(err, docs) {
		  		response.send(docs);
          });
        });
}

//Route for POST to Results page
exports.post_search_results = function (request, response) {

	var username = request.body.search;
	response.redirect('usersearch/'+username);
}

//Route for Global Highscores
exports.highscores = function (request, response) {

	response.set('Content-Type', 'text/JSON');
	
		db.collection('highscores', function(er, collection) {
		  collection.find().limit(10).sort({"score": -1}).toArray(function(err, globals) {
		  		response.send(globals);
          });
        });
}

//Route for Highscores Results
exports.highscores_results = function (request, response) {

	response.set('Content-Type', 'text/JSON');
	
	var options = {
		"limit": 10
	}
		db.collection('highscores', function(er, collection) {
		  collection.find({"game_title" : request.params.game }, options).limit(10).sort({"score":-1}).toArray(function(err, highscores) {
		  		response.send(highscores);
          });
        });
}

//Route for Submitting Database entries to Submit.json
exports.post_submit = function(request, response) {
	if(request.query.game_title && request.query.username && request.query.score){
		response.status(200);
		db.collection('highscores').insert({"game_title" : request.query.game_title, "username" : request.query.username, "score" : request.query.score });
		response.end('Valid Input!')
	}
	else {
		response.status(400);
		response.end('invalid input');
	}
}